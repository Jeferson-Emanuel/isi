package br.upe.isi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Atividade03Application {

	public static void main(String[] args) {
		SpringApplication.run(Atividade03Application.class, args);
	}

}
