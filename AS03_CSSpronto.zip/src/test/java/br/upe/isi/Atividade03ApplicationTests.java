package br.upe.isi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atividade03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
